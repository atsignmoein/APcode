#include <iostream>
#include <vector>
#include <tuple>
#include <string>

using namespace std;

#define WORD            0
#define MAP_SIZE        1
#define MAP             2

#define ROW             0
#define COLUMN          1

#define START           0
#define EMPTY           0

#define NORTH_FACTOR   -1
#define SOUTH_FACTOR    1
#define EAST_FACTOR     1
#define WEST_FACTOR    -1
#define NO_FACTOR       0

#define North           1
#define Northeast       2
#define East            3
#define Southeast       4
#define South           5
#define Southwest       6
#define West            7
#define Northwest       8
#define CHECKED_ALL     9

#define north_south     0
#define east_west       1

#define FOUND_WORD      1
#define FOR_FAILED      0

vector<vector<char>> get_map(int map_size)
{
    vector<vector<char>> map(map_size, vector<char>(map_size, ' '));
    for (int row_index = 0; row_index < map_size; row_index++)
        for (int column_index = 0; column_index < map_size; column_index++)
            cin >> map[row_index][column_index];
    return map;
}

bool coordinate_used_once(const vector<tuple<int,int>>& found_letters, tuple<int,int>& coordinate_under_test)
{
    for(int index = 0; index < found_letters.size(); index++)
        if(coordinate_under_test == found_letters[index])
            return false;
    return true;
}

void print_map(vector<vector<int>> int_map)
{
    int map_size = int_map.size();
    for(int row_index = 0; row_index < map_size; row_index++)
    {
        for (int column_index = 0; column_index < int_map.size(); column_index++)
        {
            cout << int_map[row_index][column_index];
            if(column_index == map_size - 1)
                continue;
            cout << " ";
        }
        cout << endl;
    }
}

tuple<string,int,vector<vector<char>>> get_user_input()
{
    string user_word;
    int map_size;
    cin >> user_word >> map_size;
    return make_tuple(user_word, map_size, get_map(map_size));
}

void print_vector_of_coordinates(vector<tuple<int,int>>& vec_of_tuple)
{
    for (int index = 0; index < vec_of_tuple.size(); index++)
        cout << index+1 << ". " << get<ROW>(vec_of_tuple[index]) << get<COLUMN>(vec_of_tuple[index]) << endl;
    return;
}

bool north_is_valid(int row_index) {return (row_index != 0);}

bool west_is_valid(int column_index) {return (column_index != 0);}

bool south_is_valid(const int map_size, int row_index) {return (row_index != map_size-1);}

bool east_is_valid(const int map_size, int column_index) {return (column_index != map_size-1);}

bool direction_content_matches(const vector<vector<char>>& map, tuple<int,int>& next_coordinate, const char& target_letter)
                    
{
    int row_2b = get<ROW>(next_coordinate);
    int column_2b = get<COLUMN>(next_coordinate);
    return (map[row_2b][column_2b] == target_letter);                  
}

int get_north_south_factor(int& direction)
{
    if(direction == Northwest || direction == North || direction == Northeast)
        return NORTH_FACTOR;
    if(direction == Southwest || direction == South || direction == Southeast)
        return SOUTH_FACTOR;
    return NO_FACTOR;
}

int get_east_west_factor(int& direction)
{
    if(direction == Northeast || direction == East || direction == Southeast)
        return EAST_FACTOR;
    if(direction == Southwest || direction == West || direction == Northwest)
        return WEST_FACTOR;
    return NO_FACTOR;
}

bool direction_is_valid(const tuple<int,int>& current_coordinates, int& direction, const int map_size)
{
    switch (direction)
    {
        case North:
            return north_is_valid(get<ROW>(current_coordinates));
        case Northeast:
            return north_is_valid(get<ROW>(current_coordinates)) &&
                    east_is_valid(map_size, get<COLUMN>(current_coordinates));
        case East:
            return east_is_valid(map_size, get<COLUMN>(current_coordinates));
        case Southeast:
            return south_is_valid(map_size, get<ROW>(current_coordinates)) &&
                    east_is_valid(map_size, get<COLUMN>(current_coordinates));
        case South:
            return south_is_valid(map_size, get<ROW>(current_coordinates));
        case Southwest:
            return south_is_valid(map_size, get<ROW>(current_coordinates)) &&
                    west_is_valid(get<COLUMN>(current_coordinates));
        case West:
            return west_is_valid(get<COLUMN>(current_coordinates));
        case Northwest:
            return north_is_valid(get<ROW>(current_coordinates)) &&
                    west_is_valid(get<COLUMN>(current_coordinates));
        case CHECKED_ALL:
            return true;
    }
}

tuple<int,int> make_next_coordinate(const tuple<int,int>& current_coordinates, tuple<int,int>& direction_factors)
                                            
{
    return  make_tuple(get<ROW>(current_coordinates) + get<north_south>(direction_factors),
                       get<COLUMN>(current_coordinates) + get<east_west>(direction_factors));
}

bool conditions_hold_true(const tuple<int,int>& current_coordinates, int& direction, const vector<vector<char>>& map,
                        const char& target_letter, tuple<int,int>& direction_factors, vector<tuple<int,int>>& next_letters,
                        const vector<tuple<int,int>>& letters_found, tuple<int,int>& next_coordinate)
{
    if(direction_is_valid(current_coordinates, direction, map.size()))
        if(direction_content_matches(map, next_coordinate, target_letter))
            if(coordinate_used_once(letters_found, next_coordinate))
                return true;
    return false;
}

tuple<int,int> get_direction_factors(int& direction)
{
    int north_south_factor = get_north_south_factor(direction);
    int east_west_factor = get_east_west_factor(direction);
    return make_tuple(north_south_factor, east_west_factor);
}

int set_to_next(int& direction) {return direction + 1;};

vector<tuple<int,int>> shake_neighbour(const vector<vector<char>>& map, const tuple<int,int>& current_coordinates,
                                    const char& target_letter, int& direction, vector<tuple<int,int>>& next_letters,
                                    const vector<tuple<int,int>>& letters_found)
{  
    tuple<int,int> direction_factors = get_direction_factors(direction);
    tuple<int,int> next_coordinate = make_next_coordinate(current_coordinates, direction_factors);

    if(conditions_hold_true(current_coordinates, direction, map, target_letter, direction_factors,
                            next_letters, letters_found, next_coordinate))
            next_letters.push_back(next_coordinate);

    direction = set_to_next(direction);
    if(direction == CHECKED_ALL)
        return next_letters;
    return shake_neighbour(map, current_coordinates, target_letter, direction, next_letters, letters_found);
}

vector<tuple<int,int>> find_next_letters(vector<vector<char>>& map, tuple<int,int>& current_coordinates,
                                                char& target_letter, const vector<tuple<int,int>>& letters_found)      
{
    int direction_to_look = North;
    vector<tuple<int,int>> next_letters;
    return shake_neighbour(map, current_coordinates, target_letter, direction_to_look, next_letters, letters_found);
}

bool map_coordinate_has_letter(vector<vector<char>>& map, tuple<int,int> current_index, const char& letter)
{
    return (map[get<ROW>(current_index)][get<COLUMN>(current_index)] == letter);
}
    
vector<tuple<int,int>> find_coordinates_of_letter(vector<vector<char>>& map, const char& letter)
{
    vector<tuple<int,int>> letter_coordinates;
    for (int row_index = 0; row_index < map.size(); row_index++)
        for (int column_index = 0; column_index < map.size(); column_index++)
            if(map_coordinate_has_letter(map, make_tuple(row_index, column_index), letter))
                letter_coordinates.push_back(make_tuple(row_index,column_index));
    return letter_coordinates;
}

void print_the_sequence(vector<tuple<int,int>>& word_letters, string& word)
{
    for (int index = 0; index < word_letters.size(); index++)
        cout << word[index] << " " << get<ROW>(word_letters[index]) << get<COLUMN>(word_letters[index]) << endl;
}

bool shake_branch(tuple<string,int,vector<vector<char>>>& inputs, int letter_2b_found,
                vector<tuple<int,int>> current_letters, vector<tuple<int,int>>& letters_found)
{
    for(int current_index = 0; current_index < current_letters.size(); ++current_index)
    {
        tuple<int,int> current_coordinates = current_letters[current_index];
        vector<tuple<int,int>> next_letters =
            find_next_letters(get<MAP>(inputs), current_coordinates, get<WORD>(inputs)[letter_2b_found], letters_found);
                                                
        letters_found.push_back(current_coordinates);
        if(next_letters.size() == EMPTY)
            if(letters_found.size() == get<WORD>(inputs).size())
                return FOUND_WORD;
            else
            {
                letters_found.pop_back();
                continue;
            }
        
        current_letters = next_letters;
        letter_2b_found++;

        if(shake_branch(inputs, letter_2b_found, current_letters, letters_found) == FOUND_WORD)
            return FOUND_WORD;
        else
            continue;
    }
    if(letters_found.size() != EMPTY)
        letters_found.pop_back();
    return FOR_FAILED;
}

vector<tuple<int,int>> find_word(tuple<string,int,vector<vector<char>>>& inputs)
{
    vector<tuple<int,int>> letters_found {};
    int letter_2b_found = START + 1;
    vector<tuple<int,int>> current_letters = find_coordinates_of_letter(get<MAP>(inputs), get<WORD>(inputs)[START]);
    shake_branch(inputs, letter_2b_found, current_letters, letters_found);
    return letters_found;
}

void show_letter_locations(const int& map_size, const vector<tuple<int,int>>& letter_locations)
{
    vector<vector<int>> results_map (map_size, vector<int>(map_size, EMPTY));
    for(int index = 0; index < letter_locations.size(); index++)
        results_map[get<ROW>(letter_locations[index])][get<COLUMN>(letter_locations[index])] = index + 1;
    print_map(results_map);
}
        
void show_results(tuple<string,int,vector<vector<char>>>& inputs, vector<tuple<int,int>>& letters_found)
{
    if(letters_found.size() == EMPTY)
        cout << "No" << endl;     
    else
    {
        cout << "Yes" << endl;
        show_letter_locations(get<MAP_SIZE>(inputs), letters_found);
    }
}

int main()
{
    tuple<string,int,vector<vector<char>>> inputs = get_user_input();
    vector<tuple<int,int>> letters_found = find_word(inputs);
    show_results(inputs, letters_found);
    return 0;
}