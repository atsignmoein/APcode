#include <vector>
#include <iostream>

using namespace std;

vector<int> get_tallest_heights_in_front(const vector<int>& heights, int start_index) {
    if (start_index == heights.size()-1) //stop condition
        return vector<int>({-1});
    
    int tallest_in_front_of_target = 0;                                                     //
    for (int person_index = start_index + 1; person_index < heights.size(); person_index++) //
        if(heights[person_index] > tallest_in_front_of_target)                              //finds the tallest person and stashes it "tallest_in_front_of_target"
            tallest_in_front_of_target = heights[person_index];                             //

    vector<int> tallest_vector {tallest_in_front_of_target}; //puts the current tallest person value first
    vector<int> tallest_in_the_rest = get_tallest_heights_in_front(heights, start_index + 1); //then calls the function on the next guy
    tallest_vector.insert(tallest_vector.end(), tallest_in_the_rest.begin(), tallest_in_the_rest.end()); //appends the two vectors together
    return tallest_vector;
}

vector<int> get_tallest_heights_in_front(const vector<int>& heights) {
    return get_tallest_heights_in_front(heights, 0);
}

vector<int> get_heights() {
    int height;
    vector<int> heights;
    while (cin >> height)
        heights.push_back(height);
    return heights;
}

void print_heights(const vector<int>& heights) {
    for(auto x: heights) cout << x << " ";
    cout << endl;
}

int main() {
    vector<int> heights = get_heights();
    vector<int> tallest_heights_in_front = get_tallest_heights_in_front(heights);
    print_heights(tallest_heights_in_front);
    return 0;
}
