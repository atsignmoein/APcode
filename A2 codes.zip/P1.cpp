#include <iostream>
#include <string>

using namespace std;

string get_user_input() {string s; cin >> s; return s;}

string perform_encryption(string& user_input, int from, int to)
{
    int mid = (to + from)/2;
    if (mid == 0 || to <= from)
        return string(1,user_input[mid]);
    return string(1,user_input[mid]) +
            perform_encryption(user_input, from, mid - 1) +
            perform_encryption(user_input, mid + 1, to);
}

string encryption_wrapper(string user_input)
{
    return perform_encryption(user_input, 0, user_input.size()-1);
}
    
int main()
{
    string encrypted_string = encryption_wrapper(get_user_input());
    cout << encrypted_string << endl;
    return 0;
}