#include <vector>
#include <iostream>

using namespace std;

struct HeightInfo {
    int height;
    int tallest_height_in_front;
};

void find_tallest_heights_in_front(const vector<HeightInfo *>& height_infos, int start_index) {
    if (start_index == height_infos.size()-1)//stop condition
        return;

    int tallest_in_front_of_target = 0;                                                         //
    for (int person_index = start_index + 1; person_index < height_infos.size(); person_index++)//
        if(height_infos[person_index]->height > tallest_in_front_of_target)                     //finds the tallest person and stashes it "tallest_in_front_of_target"
            tallest_in_front_of_target = height_infos[person_index]->height;                    //

    height_infos[start_index]->tallest_height_in_front = tallest_in_front_of_target; //sets the tallest_height_in_front
    find_tallest_heights_in_front(height_infos, start_index + 1); //calls the function for the next guy
}

void set_tallest_heights_in_front(const vector<HeightInfo *>& height_infos) {
    find_tallest_heights_in_front(height_infos, 0);
}

vector<HeightInfo* > get_height_infos() {
    int height;
    vector<HeightInfo*> height_infos;
    HeightInfo* temp;
    while (cin >> height)
    {
        temp = new HeightInfo;
        temp->height = height;
        temp->tallest_height_in_front = -1;
        height_infos.push_back(temp);
    }
    return height_infos;
}

void print_heights(const vector<HeightInfo *>& height_infos) {
    for(auto x: height_infos)
        cout << x->tallest_height_in_front << " ";
    cout << endl;
}

int main() {
    vector<HeightInfo *> height_infos = get_height_infos();
    set_tallest_heights_in_front(height_infos);
    print_heights(height_infos);
    return 0;
}
